package project.n01349430.gurbhinder

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class HelpMenu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_menu)
    }
}