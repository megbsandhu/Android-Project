package project.n01349430.gurbhinder

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [SuggestionEntity::class], version = 5)
abstract class SuggestionDatabase : RoomDatabase() {


    abstract fun suggestionDao():SuggestionDao

    companion object {

        @Volatile
        private var INSTANCE: SuggestionDatabase? = null

        fun getInstance(context: Context): SuggestionDatabase {
            if (INSTANCE == null) {
                INSTANCE = Room.databaseBuilder(
                    context,
                    SuggestionDatabase::class.java,
                    "suggestions.db")
                    .fallbackToDestructiveMigration()
                    .build()
            }
            return INSTANCE as SuggestionDatabase
        }
    }
}