package project.n01349430.gurbhinder

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main3.*
import kotlinx.android.synthetic.main.activity_main3.buttonMen
import kotlinx.android.synthetic.main.activity_main3.deliveryEt
import kotlinx.android.synthetic.main.activity_main3.switch1
import kotlinx.android.synthetic.main.activity_main3.textView5
import kotlinx.android.synthetic.main.activity_main3.total
import kotlinx.android.synthetic.main.activity_main4.*

class MainActivity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)

        val intent = getIntent()

        val sizes = arrayOf("6", "7", "8", "9", "10")

        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sizes)


        // attached arrayAdapter to spinner
        spinner2.adapter = arrayAdapter

        spinner2.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
                // To change body of created
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                //To change body of created
            }
        }

        var clothPrice = 0;
        var shoePrice = 0;
        var sizePrice = 0;
        var totalPrice = 0;

        cb8.setOnCheckedChangeListener { compoundButton, b ->
            if (cb8.isChecked) {
                clothPrice += 100;
                totalPrice = clothPrice + sizePrice;
            } else {
                clothPrice -= 100;
                totalPrice = clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        cb9.setOnCheckedChangeListener { compoundButton, b ->
            if (cb9.isChecked) {
                clothPrice += 80;
                totalPrice = clothPrice + sizePrice;
            } else {
                clothPrice -= 80;
                totalPrice = clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        cb10.setOnCheckedChangeListener { compoundButton, b ->
            if (cb10.isChecked) {
                clothPrice += 50;
                totalPrice = clothPrice + sizePrice;
            } else {
                clothPrice -= 50;
                totalPrice = clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        cb11.setOnCheckedChangeListener { compoundButton, b ->
            if (cb11.isChecked) {
                clothPrice += 40;
                totalPrice = clothPrice + sizePrice;
            } else {
                clothPrice -= 40;
                totalPrice = clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        radioGroup3.setOnCheckedChangeListener { radioGroup, checkedId ->
            if (checkedId == R.id.rbs1) {
                sizePrice = 5;
                totalPrice = clothPrice + sizePrice;
            } else if (checkedId == R.id.rbs2) {
                sizePrice = 5;
                totalPrice = clothPrice + sizePrice;
            } else if (checkedId == R.id.rbs3) {
                sizePrice = 5;
                totalPrice = clothPrice + sizePrice;
            }
            total.text = "Total Price: $" + totalPrice;
        }
        cb12.setOnCheckedChangeListener { compoundButton, b ->
            if (cb12.isChecked) {
                shoePrice += 120;
                totalPrice = shoePrice + clothPrice + sizePrice;
            } else {
                shoePrice -= 120;
                totalPrice = shoePrice + clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        cb13.setOnCheckedChangeListener { compoundButton, b ->
            if (cb13.isChecked) {
                shoePrice += 100;
                totalPrice = shoePrice + clothPrice + sizePrice;
            } else {
                shoePrice -= 100;
                totalPrice = shoePrice + clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        cb14.setOnCheckedChangeListener { compoundButton, b ->
            if (cb14.isChecked) {
                shoePrice += 150;
                totalPrice = shoePrice + clothPrice + sizePrice;
            } else {
                shoePrice -= 150;
                totalPrice = shoePrice + clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        // for switch
        deliveryWomen.visibility = View.INVISIBLE
        buttonWomen.visibility = View.INVISIBLE
        switchWomen.setOnCheckedChangeListener { compoundButton, isChecked ->
            if (isChecked) {
                // if the toggleButton is enabled
                textWomen.text = "Delivery details:\n Please, enter your address:"
                deliveryWomen.visibility = View.VISIBLE
                buttonWomen.visibility = View.VISIBLE
                deliveryWomen.text.isEmpty()
            }
        }
        buttonWomen.setOnClickListener {
            var text = deliveryWomen.text
            Toast.makeText(this, text, Toast.LENGTH_LONG).show()
        }

    }
    fun shoppingCart(view: View) {
        // collect checkboxes values
        var output = ""
        /* val names = listOf("cb1.text.toString()","cb2.text.toString()","cb3.text.toString()","cb4.text.toString()","cb5.text.toString()")
        for(name in names) {
            output += "/n"+name
        }*/
        if (cb8.isChecked) {
            output = cb8.text.toString()
        }
        if (cb9.isChecked) {
            output += "\n" + cb9.text.toString()
        }
        if (cb10.isChecked) {
            output += "\n" + cb10.text.toString()
        }
        if (cb11.isChecked) {
            output += "\n" + cb11.text.toString()
        }
        if (cb12.isChecked) {
            output += "\n" + cb12.text.toString()
        }
        if (cb13.isChecked) {
            output += "\n" + cb13.text.toString()
        }
        if (cb14.isChecked) {
            output += "\n" + cb14.text.toString()
        }
       // var totalCost = totalPrice + totalPrice*.13
        // start intent
        val intent = Intent(this@MainActivity4, MainActivity5::class.java)

        //intent.putExtra("Out", output)
        //intent.putExtra("Total", totalCost)

        startActivity(intent)
    }
    fun openSuggestionBox(view: View) {
        // start intent
        val intent = Intent(this@MainActivity4, MainActivity6::class.java)
        startActivity(intent)
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    // actions on click menu items
    override fun onOptionsItemSelected(item: MenuItem)  = when (item.itemId) {

        R.id.action_about -> {
            startActivity(Intent(this@MainActivity4, AboutMenu::class.java))
            true
        }
        R.id.action_help -> {
            startActivity(Intent(this@MainActivity4, HelpMenu::class.java))
            true
        }
        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }
}