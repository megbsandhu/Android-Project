package project.n01349430.gurbhinder

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main6.*
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.toast
import org.jetbrains.anko.uiThread

class MainActivity6 : AppCompatActivity() {

    private lateinit var mDb:SuggestionDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main6)

        //get intent
        val intent = getIntent()

        // Initialize the room database
        mDb = SuggestionDatabase.getInstance(applicationContext)

        // Make the text view scrollable
        val txtData = findViewById<TextView>(R.id.txtData)
        txtData.movementMethod = ScrollingMovementMethod()


        // Insert button click listener
        val insert = findViewById<Button>(R.id.btnInsert)
        insert.setOnClickListener{
            val item = editCategory.text.toString()
            val size = editSize.text.toString()
            // Initialize a new suggestion with some random data
            val suggestion = SuggestionEntity(0,
                category = item,
                size = size
            )

            doAsync {
                // do things in the background  // (1)
                mDb.suggestionDao().insert(suggestion)     // Put the suggestion in database
                uiThread {
                    // make changes to the UI   // (2)
                    toast("record inserted")
                }
            }
        }

        // View button click listener
        val view = findViewById<Button>(R.id.btnView)
        view.setOnClickListener{
            doAsync {
                // do things in the background  // (1)

                val list = mDb.suggestionDao().getAll()  // Get the suggestion list from database

                uiThread {
                    // make changes to the UI     // (2)
                    toast("${list.size} records found.")
                    txtData.text = "" // Display the suggestions in text view with grade
                    for (suggestion in list){
                        txtData.append("${suggestion.id} : ${suggestion.category} : ${suggestion.size}\n")
                    }
                }
            }
        }
        // Delete button click listener
        val delete = findViewById<Button>(R.id.btnDelete)
        delete.setOnClickListener{

            doAsync {
                // do things in the background  // (1)
                mDb.suggestionDao().delete()     // delete all suggestions from database
                uiThread {
                    // make changes to the UI   // (2)
                    toast("record deleted")
                }
            }
            editCategory.setText(" ")
            editSize.setText(" ")
            txtData.text = " "
        }

       //update data
        // update button click listener
      /*  val item2 = editCategory.text.toString()
        val size2 = editSize.text.toString()
        val update = findViewById<Button>(R.id.btnUpdate)
        update.setOnClickListener{
            val suggestion = SuggestionEntity(0,
                category = item2,
                size = size2
            )

            doAsync {
                // do things in the background  // (1)
                mDb.suggestionDao().update(suggestion)     // Update the suggestion in database
                uiThread {
                    // make changes to the UI   // (2)
                    toast("record updated")
                }
            }
        }*/
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    // actions on click menu items
    override fun onOptionsItemSelected(item: MenuItem)  = when (item.itemId) {

        R.id.action_about -> {
            startActivity(Intent(this@MainActivity6, AboutMenu::class.java))
            true
        }
        R.id.action_help -> {
            startActivity(Intent(this@MainActivity6, HelpMenu::class.java))
            true
        }
        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }
}