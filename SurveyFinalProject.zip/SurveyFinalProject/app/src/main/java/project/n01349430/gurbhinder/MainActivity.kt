package project.n01349430.gurbhinder

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val pref = getPreferences(Context.MODE_PRIVATE)
        val username = pref.getString("USERNAME", "")
        val password = pref.getString("PASSWORD", "")
        editName.setText(username)
        editPassword.setText(password.toString())

    }

    fun onLogin(view: View) {

        //create shared preferences file
        val pref = getPreferences(Context.MODE_PRIVATE)
        val editor = pref.edit()
        // collect username from editName
        val name = editName.text.toString()
        val password = editPassword.text.toString()

        // save username
        if(!(name==""&&password=="")) {
            editor.putString("USERNAME", editName.text.toString())
            //save password
            editor.putString("PASSWORD", editPassword.text.toString())
            //commit changes
            editor.commit()

            val toast = Toast.makeText(applicationContext, "Data Saved", Toast.LENGTH_LONG)
            toast.show()
        }


        if(name!=""&&password!="") {
            // start intent
            val intent = Intent(this@MainActivity, MainActivity2::class.java)

            intent.putExtra("Name", name)

            startActivity(intent)
        }
        else{
            Toast.makeText(this,"Enter username or password", Toast.LENGTH_SHORT).show()
        }
    }

    fun clearData(view: View) {
        val pref = getPreferences(Context.MODE_PRIVATE)
        val editor = pref.edit()
        editor.clear()
        editor.commit()

        editName.setText("")
        editPassword.setText("")


    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    // actions on click menu items
    override fun onOptionsItemSelected(item: MenuItem)  = when (item.itemId) {

        R.id.action_about -> {
            startActivity(Intent(this@MainActivity, AboutMenu::class.java))
           true
        }
        R.id.action_help -> {
            startActivity(Intent(this@MainActivity, HelpMenu::class.java))
            true
        }
        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }

}