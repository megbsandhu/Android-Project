package project.n01349430.gurbhinder

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_main5.*

class MainActivity5 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main5)

        //get intent object, and data from intent
        val intent = getIntent()

        val output = intent.getStringExtra("Output")
       // val out = intent.getStringExtra("Out")
        //val total = intent.getDoubleExtra("Total",0.0)

        val mytext = findViewById<TextView>(R.id.textView14)
        mytext.movementMethod = ScrollingMovementMethod()

        mytext.text = "\nItemList:\n\n"+output//+"\n\nTotal Price: "+ total
        //mytext.text = "\nItemList:\n\n"+out
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    // actions on click menu items
    override fun onOptionsItemSelected(item: MenuItem)  = when (item.itemId) {

        R.id.action_about -> {
            startActivity(Intent(this@MainActivity5, AboutMenu::class.java))
            true
        }
        R.id.action_help -> {
            startActivity(Intent(this@MainActivity5, HelpMenu::class.java))
            true
        }
        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }
}