package project.n01349430.gurbhinder

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_main3.*

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        //get intent object, and data from intent
        val intent = getIntent()
        val name = intent.getStringExtra("Name")

        textUser.text = "Hi ! "+name

    }

    fun goAhead(view: View) {
        if(rbMale.isChecked) {
            // start intent
            if(cbCloth.isChecked||cbShoes.isChecked) {
                if(cbConditions.isChecked) {
                    textConditions.visibility = View.INVISIBLE
                    val intent = Intent(this@MainActivity2, MainActivity3::class.java)
                    startActivity(intent)
                }
                else{
                    textConditions.visibility = View.VISIBLE
                }
            }
            else{
                val toast = Toast.makeText(applicationContext, "Please select at least one category", Toast.LENGTH_LONG)
                toast.show()
            }
        }
        else if(rbFemale.isChecked){
            // start intent
            if(cbCloth.isChecked||cbShoes.isChecked) {
                if(cbConditions.isChecked) {
                    textConditions.visibility = View.INVISIBLE
                    val intent = Intent(this@MainActivity2, MainActivity4::class.java)
                    startActivity(intent)
                }
                else{
                    textConditions.visibility = View.VISIBLE
                }
            }
            else{
                val toast = Toast.makeText(applicationContext, "Please select at least one category", Toast.LENGTH_LONG)
                toast.show()
            }
        }
        else{
            val toast = Toast.makeText(applicationContext, "Please select gender", Toast.LENGTH_LONG)
            toast.show()
        }
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    // actions on click menu items
    override fun onOptionsItemSelected(item: MenuItem)  = when (item.itemId) {

        R.id.action_about -> {
            startActivity(Intent(this@MainActivity2, AboutMenu::class.java))
            true
        }
        R.id.action_help -> {
            startActivity(Intent(this@MainActivity2, HelpMenu::class.java))
            true
        }
        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }
}