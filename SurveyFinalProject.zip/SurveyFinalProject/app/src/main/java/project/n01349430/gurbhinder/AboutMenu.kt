package project.n01349430.gurbhinder

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AboutMenu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_menu)
    }
}