package project.n01349430.gurbhinder

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.buttonMen
import kotlinx.android.synthetic.main.activity_main3.*

class MainActivity3 : AppCompatActivity() {
    var totalPrice = 0;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val intent = getIntent()


        val sizes = arrayOf("8", "9", "10", "11", "12")

        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sizes)


        // attached arrayAdapter to spinner
        spinner.adapter = arrayAdapter

        spinner.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
                // To change body of created
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                //To change body of created
            }
        }

        var clothPrice = 0;
        var shoePrice = 0;
        var sizePrice = 0;


        cb1.setOnCheckedChangeListener { compoundButton, b ->
            if (cb1.isChecked) {
                clothPrice += 100;
                totalPrice = clothPrice + sizePrice;
            } else {
                clothPrice -= 100;
                totalPrice = clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        cb2.setOnCheckedChangeListener { compoundButton, b ->
            if (cb2.isChecked) {
                clothPrice += 80;
                totalPrice = clothPrice + sizePrice;
            } else {
                clothPrice -= 80;
                totalPrice = clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        cb3.setOnCheckedChangeListener { compoundButton, b ->
            if (cb3.isChecked) {
                clothPrice += 50;
                totalPrice = clothPrice + sizePrice;
            } else {
                clothPrice -= 50;
                totalPrice = clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        cb4.setOnCheckedChangeListener { compoundButton, b ->
            if (cb4.isChecked) {
                clothPrice += 40;
                totalPrice = clothPrice + sizePrice;
            } else {
                clothPrice -= 40;
                totalPrice = clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        radioGroup.setOnCheckedChangeListener { radioGroup, checkedId ->
            if (checkedId == R.id.rbSize1) {
                sizePrice = 5;
                totalPrice = clothPrice + sizePrice;
            } else if (checkedId == R.id.rbSize2) {
                sizePrice = 5;
                totalPrice = clothPrice + sizePrice;
            } else if (checkedId == R.id.rbSize3) {
                sizePrice = 5;
                totalPrice = clothPrice + sizePrice;
            }
            total.text = "Total Price: $" + totalPrice;
        }
        cb5.setOnCheckedChangeListener { compoundButton, b ->
            if (cb5.isChecked) {
                shoePrice += 120;
                totalPrice = shoePrice + clothPrice + sizePrice;
            } else {
                shoePrice -= 120;
                totalPrice = shoePrice + clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        cb6.setOnCheckedChangeListener { compoundButton, b ->
            if (cb6.isChecked) {
                shoePrice += 100;
                totalPrice = shoePrice + clothPrice + sizePrice;
            } else {
                shoePrice -= 100;
                totalPrice = shoePrice + clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        cb7.setOnCheckedChangeListener { compoundButton, b ->
            if (cb7.isChecked) {
                shoePrice += 150;
                totalPrice = shoePrice + clothPrice + sizePrice;
            } else {
                shoePrice -= 150;
                totalPrice = shoePrice + clothPrice + sizePrice;
            }
            total.text = "Total Price: " + totalPrice;
        }
        // for switch
        deliveryEt.visibility = View.INVISIBLE
        buttonMen.visibility = View.INVISIBLE
        switch1.setOnCheckedChangeListener { compoundButton, isChecked ->
            if (isChecked) {
                // if the toggleButton is enabled
                textView5.text = "Delivery details:\n Please, enter your address:"
                deliveryEt.visibility = View.VISIBLE
                buttonMen.visibility = View.VISIBLE
                deliveryEt.text.isEmpty()
            }
        }
        buttonMen.setOnClickListener {
            var text = deliveryEt.text
            Toast.makeText(this, text, Toast.LENGTH_LONG).show()
        }
    }
        fun openShoppingCart(view: View) {
            // collect checkboxes values
            var output = ""
            /* val names = listOf("cb1.text.toString()","cb2.text.toString()","cb3.text.toString()","cb4.text.toString()","cb5.text.toString()")
            for(name in names) {
                output += "/n"+name
            }*/
            if (cb1.isChecked) {
                output = cb1.text.toString()
            }
            if (cb2.isChecked) {
                output += "\n" + cb2.text.toString()
            }
            if (cb3.isChecked) {
                output += "\n" + cb3.text.toString()
            }
            if (cb4.isChecked) {
                output += "\n" + cb4.text.toString()
            }
            if (cb5.isChecked) {
                output += "\n" + cb5.text.toString()
            }
            if (cb6.isChecked) {
                output += "\n" + cb6.text.toString()
            }
            if (cb7.isChecked) {
                output += "\n" + cb7.text.toString()
            }
            val totalCost = totalPrice + totalPrice*.13

            // start intent
            val intent = Intent(this@MainActivity3, MainActivity5::class.java)

            intent.putExtra("Output", output)
            intent.putExtra("Total", totalCost)

            startActivity(intent)
        }

    fun openSuggestions(view: View) {
        // start intent
        val intent = Intent(this@MainActivity3, MainActivity6::class.java)
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    // actions on click menu items
    override fun onOptionsItemSelected(item: MenuItem)  = when (item.itemId) {

        R.id.action_about -> {
            startActivity(Intent(this@MainActivity3, AboutMenu::class.java))
            true
        }
        R.id.action_help -> {
            startActivity(Intent(this@MainActivity3, HelpMenu::class.java))
            true
        }
        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }


}

