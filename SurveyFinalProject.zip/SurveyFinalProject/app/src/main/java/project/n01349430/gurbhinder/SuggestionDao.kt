package project.n01349430.gurbhinder

import androidx.room.*

@Dao
interface SuggestionDao{
    @Query("SELECT * FROM suggestions")
    fun getAll(): List<SuggestionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(student: SuggestionEntity)

    @Update(onConflict = OnConflictStrategy.REPLACE)
    fun update(student: SuggestionEntity)

    @Query("Delete from suggestions")
    fun delete()
}